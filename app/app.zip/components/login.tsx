'use client';

import { signIn, signOut } from "next-auth/react";
import Link from "next/link";
import { useCustomSession } from "../sessions";


interface userInfo {
  name:string;
  email:string;
  image:string;
}

interface PropsData{
  session?: userInfo | null
}


export default function Login(){
  const {data:session, status} =useCustomSession();
  const redirectTo =()=>{
    sessionStorage.setItem('preUrl', window.location.href);
    window.location.href ="/login"
  }
  return(
    <>
    { session && session.user?.level === 10 ?
      '관리자'
       : 
      session && session.user?.level !== null && '일반회원' }
      {/* {console.log(session && session.user)} */}
      {status !== 'loading' && session && session.user?.email ? 
      <>
      <p>{session && session.user?.name}님 반갑습니다.</p>
      <button onClick={()=>{signOut()}}>로그아웃</button>
      </>
      :
      <>
   
       <Link href='/register'>회원가입</Link>
       <button onClick={redirectTo}>로그인</button>
       {/* <button onClick={()=>{signIn('kakao')}}>카카오로그인</button>
       <button onClick={()=>{signIn('naver')}}>네이버로그인</button>
       <button onClick={()=>{signIn('github')}}>깃허브로그인</button>
       <button onClick={()=>{signIn('google')}}>구글로그인</button>
       <button onClick={()=>{signIn('credential')}}>메일로그인</button> */}
      </>
       }
    </>
    
   
    
  )
}