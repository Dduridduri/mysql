import Image from 'next/image'
import Post from './components/post'
import Write from './write/page'

export default function Home() {
  return (
    <>
      <Post/>
      <Write/>
    </>
   
  )
}
